export default function Square() {
  return (
    <div>
      <button className="square">X</button>
      <button className="square">X</button>
    </div>
  );
}
